# Drop into the repo root — aistrangegame/aistrangegame.com

Everything here is laid out to the repo's root. Nothing overlaps existing files except `Default.html`
(the homepage with the three new doorways and the Maya practice link — diff it against yours before replacing).

## Option A — no terminal (GitHub web)
Open the repo → "Add file" → "Upload files" → drag the *folders* (tree-of-life, door, guide, bindu, teachings, learning, forms) into the box.
Modern browsers keep the folder structure. Commit message: `site: session build 2026-09-22 (positions 21–33, door, guide, readings, teachings, learning, forms)`.

## Option B — three commands
```
cd aistrangegame.com            # your local clone
unzip -o ~/Downloads/repo-drop.zip -d .   # lands folders at the root
git add . && git commit -m "site: session build 2026-09-22" && git push
```

## Before either — the seed
The domain is already on Cloudflare and serves only the homepage. Everything else on the site
(story, chakras, tree-of-life 1–20, dances, family, person pages) is still only on SiteGround and 404s at the domain right now.
Download SiteGround `public_html`, commit it at the repo root first, then add this drop on top.
Cloudflare Pages deploys on push; the site is whole again in a minute or two.

## Not for the repo (it's public)
The handoff folders, generators, register, and the padakarshini skill stay out of the site repo. Give those to Claude Code separately (claude-code-handoff.zip).
